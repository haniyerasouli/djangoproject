from django.db import models
from django.template.defaultfilters import slugify


# Create your models here.
class Shoe(models.Model):
    property=models.CharField(max_length=30)
    color=models.CharField(max_length=30)
    production_date=models.DateField()
    price=models.DecimalField(max_digits=8,decimal_places=2)
    # speces=models.FileField(upload_to='files/shoes')
    photo=models.ImageField(upload_to='files/shoes')
    brand=models.CharField(max_length=30)
    gender=models.CharField(max_length=10)
    slug=models.SlugField(default='',null=False,db_index=True)



def save(self,*args,**kwargs):
    self.slug=slugify(self.property,self.brand,self.color)
    super().save(*args,**kwargs)